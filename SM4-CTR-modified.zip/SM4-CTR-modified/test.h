#include <stdint.h>

typedef unsigned char muint8;  //一个字节
typedef unsigned long muint32; //4个字节 

muint32 linear_transform(muint32 b);
muint32 clshift(muint32 b, int n);