#include <stdint.h>

typedef uint8_t muint8;  //一个字节
typedef uint32_t muint32; //4个字节 

void SM4Crypt(const muint8* input, muint8* output, muint32* rk, const muint8* plaintext);
void SM4KeyExt(muint8* Key, muint32* rk, muint32 CryptFlag);
void SM4_cpu_ctr(char* text, char* cipher, int size, muint32* key, muint8* Counter);