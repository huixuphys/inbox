#define SM4
// #define TEST
// #define SM4TEST